BRIGHTPOWER ELECTRICAL WEBSITE
6 pages:
1. index.html - Home
2. services.html - Services
3. residential.html - Residential
4. commercial.html - Commercial
5. projects.html - Projects
6. contact.html - Contact / Quote

Open index.html in a browser to preview.
Replace the example phone, email, service areas and photography with the contractor's real details before publishing.
The site uses remote Unsplash images for the visual mockup.
