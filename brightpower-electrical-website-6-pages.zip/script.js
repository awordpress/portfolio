
document.querySelectorAll('[data-menu]').forEach(btn=>{
  btn.addEventListener('click',()=>document.querySelector('.menu').classList.toggle('open'));
});
document.querySelectorAll('a[href^="#"]').forEach(a=>{
  a.addEventListener('click',e=>{
    const el=document.querySelector(a.getAttribute('href'));
    if(el){e.preventDefault();el.scrollIntoView({behavior:'smooth'});}
  });
});
document.querySelectorAll('.form').forEach(form=>{
  form.addEventListener('submit',e=>{
    e.preventDefault();
    const msg=form.querySelector('.form-message');
    if(msg){msg.textContent='Thank you. Your quote request has been received.';msg.style.color='#b27600';}
  });
});
